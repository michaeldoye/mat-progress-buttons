# simple-ui-lib
## ng-conf presentation example

This app was used in an [ng-conf presentation](https://www.youtube.com/watch?v=unICbsPGFIA) as a sample for building a library using the [Angular Package Format](https://goo.gl/AMOU5G). There may be updates to this code, but for an on-going reference see Filipe Silva's [Angular Quickstart Lib](https://github.com/filipesilva/angular-quickstart-lib) project.

Install this project using `npm install simple-ui-lib`.