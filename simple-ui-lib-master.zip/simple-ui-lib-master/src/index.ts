
export * from './components/box.module';